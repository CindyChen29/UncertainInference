/**
 * Base implementations of the core data structures for Bayesian Networks.
 */
package bn.base;