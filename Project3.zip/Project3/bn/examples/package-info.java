/**
 * Examples of BayesianNetworks built manually.
 * <p>
 * The source directory for this package includes examples of BIF and
 * XMLBIF files describing these and other Bayesian networks.
 */
package bn.examples;