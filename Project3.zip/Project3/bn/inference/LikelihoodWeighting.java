package bn.inference;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import bn.core.Assignment;
import bn.base.BayesianNetwork;
import bn.base.Distribution;
import bn.base.StringValue;
import bn.core.RandomVariable;
import bn.util.ArrayMap;

public class LikelihoodWeighting {
	public Random random = new Random();

/*
 * function LIKELIHOOD-WEIGHTING(X, e, bn,N) returns an estimate of P(X|e)
		inputs: X, the query variable
				e, observed values for variables E
				bn, a Bayesian network specifying joint distribution P(X1, . . . , Xn)
				N, the total number of samples to be generated
	local variables: W, a vector of weighted counts for each value of X, initially zero
	for j = 1 to N do
		x,w ←WEIGHTED-SAMPLE(bn, e)
		W[x ]←W[x] + w where x is the value of X in x
	return NORMALIZE(W)
	
*/
	
	public bn.base.Distribution likelihoodWeighting(RandomVariable X, Assignment e, BayesianNetwork bn, int N) {
		bn.base.Distribution Q=new bn.base.Distribution(X);
		
		for(int j=0;j<N;j++) {
			Map<Assignment, Double> temp=new ArrayMap<Assignment, Double>();
			temp=weightedSample(bn, e);
			for(Assignment a: temp.keySet()) {
				if(!Q.containsKey(a.get(X))) {
					Q.put(a.get(X), temp.get(a));
				}else {
					Q.put(a.get(X), (Q.get(a.get(X))+temp.get(a)));
				}
			}
		}

		Q.normalize();
		return Q;
	}
	


	public void randomSampling(RandomVariable X, Assignment assignment, BayesianNetwork bn) {
		Double[] intervalArray=new Double[X.getDomain().size()];
		Map<bn.core.Value, Double[]> valueMap=new HashMap<bn.core.Value, Double[]>();
		double sum=0.0;
		for(bn.core.Value v: X.getDomain()) {
			intervalArray=new Double[X.getDomain().size()];
			assignment.put(X, v);
			for(int i=0; i<intervalArray.length;i++) {
				intervalArray[i]=sum;
				if(i!=intervalArray.length-1)
					sum+=bn.getProbability(X, assignment);
			}
			valueMap.put(v, intervalArray);
			
		}
		
		double p=random.nextDouble();

		for(bn.core.Value v: valueMap.keySet()) {
			for(int i=0;i<intervalArray.length-1;i++) {
				if(p>=valueMap.get(v)[i]&&p<=valueMap.get(v)[i+1])
					assignment.put(X, v);
			}
		}
		
	}
	/*
	function WEIGHTED-SAMPLE(bn, e) returns an event and a weight
	w ←1; x←an event with n elements initialized from e
	foreach variable Xi in X1, . . . , Xn do
		if Xi is an evidence variable with value xi in e
			then w ←w × P(Xi = xi | parents(Xi))
		else x[i]←a random sample from P(Xi | parents(Xi))
	return x, w
*/
	public Map<Assignment, Double> weightedSample(BayesianNetwork bn, Assignment e){
		double w=1.0;
		Map<Assignment, Double> result=new ArrayMap<Assignment, Double>();
		Assignment newE=e.copy();
		List<RandomVariable> list= bn.getVariablesSortedTopologically();

		for(RandomVariable xi: list) {
			if(e.containsKey(xi)) {
				w=w*bn.getProbability(xi, newE);
				//evidence add to sample
			}else {
				randomSampling(xi, newE, bn);
						
			}
		}
		
		result.put(newE, w);
		return result;
	}
	

}
