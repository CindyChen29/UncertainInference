package bn.inference;

import java.io.FileInputStream;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import bn.base.BayesianNetwork;
import bn.base.StringValue;
import bn.core.Assignment;
import bn.core.Distribution;
import bn.core.RandomVariable;
import bn.parser.BIFParser;
import bn.parser.XMLBIFParser;

public class mainClass {
	public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException{
		String comment=args[0];
		String queryName="";
		String fileName="";
		String evidence="";
		int sampleSize=0;

		switch (comment) {
		case "MyBNInferencer":
			fileName=args[1];
			queryName=args[2];
			for(int i=3;i<args.length;i++) {
				evidence+=args[i];
				evidence+=" ";

			}
			
			break;
		case "RejectionSamplingInference":
			sampleSize=Integer.parseInt(args[1]);
			fileName=args[2];
			queryName=args[3];
			for(int i=4;i<args.length;i++) {
				evidence+=args[i];
				evidence+=" ";

			}

			break;
		case "LikelihoodWeightingInference":
			sampleSize=Integer.parseInt(args[1]);
			fileName=args[2];
			queryName=args[3];
			for(int i=4;i<args.length;i++) {
				evidence+=args[i];
				evidence+=" ";

			}
			break;
		case "GibbsSamplingInference":
			sampleSize=Integer.parseInt(args[1]);
			fileName=args[2];
			queryName=args[3];
			for(int i=4;i<args.length;i++) {
				evidence+=args[i];
					evidence+=" ";
			}
			break;
		default:
			break;
		}
		
		

			String filePath="./bn/examples/"+fileName;


			BayesianNetwork BN = new bn.base.BayesianNetwork();


			if(fileName.endsWith("xml")) {
				XMLBIFParser parser=new XMLBIFParser();
				BN=(BayesianNetwork) parser.readNetworkFromFile(filePath);
			}else if(fileName.endsWith("bif")) {
				BIFParser parser=new BIFParser(new FileInputStream(filePath));
				BN=(BayesianNetwork) parser.parseNetwork();
			}

			System.out.println("You chose "+comment);
			System.out.println("queryName="+queryName);
			System.out.println("fileName="+fileName);
			System.out.println("evidence="+evidence);


			
			RandomVariable query=BN.getVariableByName(queryName);

			Assignment e=new bn.base.Assignment();
			String[] evidenceDetails=evidence.split(" ");


			for(int i=0;i<evidenceDetails.length;i=i+2) {

				e.put(BN.getVariableByName(evidenceDetails[i]), new StringValue(evidenceDetails[i+1]));

			}


			switch (comment) {
			case "MyBNInferencer":
				bn.inference.EnumerationInferencer enumerationInferencer=new bn.inference.EnumerationInferencer();
				Distribution distribution=enumerationInferencer.query(query, e, BN);
				System.out.println(distribution.toString());
				break;

			case "RejectionSamplingInference":
				System.out.println("sampleSize="+sampleSize);

				bn.inference.RejectionSampling rs=new RejectionSampling();
				Distribution distribution2=rs.rejectionSampling(query, e, BN, sampleSize);
				System.out.println(distribution2.toString());

				break;
			case "LikelihoodWeightingInference":
				System.out.println("sampleSize="+sampleSize);

				bn.inference.LikelihoodWeighting lw=new LikelihoodWeighting();
				Distribution distribution3=lw.likelihoodWeighting(query, e, BN, sampleSize);
				System.out.println(distribution3.toString());

				break;
			case "GibbsSamplingInference":
				System.out.println("sampleSize="+sampleSize);

				bn.inference.GibbsSampling gs=new GibbsSampling();
				Distribution distribution4=gs.GibbsAsk(query, e, BN, sampleSize);
				System.out.println(distribution4.toString());

				break;
			default:
				break;
			}


		

	}

}
