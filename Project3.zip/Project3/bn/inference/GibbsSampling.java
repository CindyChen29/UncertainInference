package bn.inference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import bn.core.Assignment;
import bn.base.BayesianNetwork;
import bn.base.Distribution;
import bn.base.StringValue;
import bn.base.Value;
import bn.core.RandomVariable;

public class GibbsSampling {
	public Random random = new Random();

/*
 * function GIBBS-ASK(X, e, bn,N) returns an estimate of P(X|e)
	local variables: N, a vector of counts for each value of X, initially zero
					 Z, the nonevidence variables in bn
					 x, the current state of the network, initially copied from e
	
	initialize x with random values for the variables in Z
	for j = 1 to N do
		for each Zi in Z do
			N[x ]←N[x] + 1 where
 */
	
	public Distribution GibbsAsk(RandomVariable X, Assignment e, BayesianNetwork bn, int N) {
		Distribution Q=new Distribution(X);
		
		List<RandomVariable> evidence=bn.getVariablesSortedTopologically();
		List<RandomVariable> Z=evidence;

		//form a non-evidence list
		for(RandomVariable xi:e.keySet()) {
			if(evidence.contains(xi)) {
				Z.remove(xi);
			}
		}
		
		//initialize x with random values for the variables in Z
		Assignment newE=e.copy();
		newE=Initialization(newE, Z);
		
		for(int j=0;j<N;j++) {
			for(RandomVariable zi: Z) {
				bn.core.Value value=MarkovBlanket(zi, bn, newE);
				
				
				newE.put(zi, value);
				if(!Q.containsKey(newE.get(X))) {
					Q.put(newE.get(X), 1.0);
				}else {
					Q.put(newE.get(X), Q.get(newE.get(X))+1.0);
				}
			}
		}
		Q.normalize();
		return Q;
	}
	
	public Assignment Initialization(Assignment assignment, List<RandomVariable> Z) {
		Random random=new Random();
		double p=0.0;
		for(RandomVariable xi: Z) {
			p=random.nextDouble();
			if(p<0.5) {
				assignment.put(xi, new StringValue("true"));
			}else {
				assignment.put(xi, new StringValue("false"));
			}
		}
		return assignment;
	}
	
	public bn.core.Value MarkovBlanket(RandomVariable z, BayesianNetwork bn, Assignment e) {
		Set<RandomVariable> childrenSet=bn.getChildren(z);
		Assignment newE=e.copy();
		
		Distribution markovBlanketDistribution=new Distribution(z);
		
		for(bn.core.Value v: z.getDomain()) {
			newE.put(z, v);
			
			double prob=bn.getProbability(z, newE);
			
			for(RandomVariable c: childrenSet) {
				prob=prob*bn.getProbability(c, newE);
			}
			
			markovBlanketDistribution.put(v, prob);
		}
		
		markovBlanketDistribution.normalize();
		
		
			Double[] intervalArray=new Double[z.getDomain().size()];
			Map<bn.core.Value, Double[]> valueMap=new HashMap<bn.core.Value, Double[]>();
			double sum=0.0;
			for(bn.core.Value v: z.getDomain()) {
				intervalArray=new Double[z.getDomain().size()];
				for(int i=0; i<intervalArray.length;i++) {
					intervalArray[i]=sum;
					if(i!=intervalArray.length-1)
						sum+=markovBlanketDistribution.get(v);
				}
				valueMap.put(v, intervalArray);
				
			}
			
			double p=random.nextDouble();

			for(bn.core.Value v: valueMap.keySet()) {
				for(int i=0;i<intervalArray.length-1;i++) {
					if(p>=valueMap.get(v)[i]&&p<=valueMap.get(v)[i+1])
						return v;
				}
			}
			return null;
	}
		
		


	
	
}
