package bn.inference;

import java.util.List;

import bn.core.BayesianNetwork;
import bn.core.Assignment;
import bn.core.RandomVariable;



public class EnumerationInferencer implements bn.core.Inferencer{
	
	/*
	Function  Enumeration-Ask(X, e, bn) returns a distribution over X
		inputs: X the query variable
				e, observed values for variable E
				bn, a Bayes net with variables {X} U E U Y  [Y=hidden variables]
				
		Q(X) <-- a distribution over X, initially empty
		for each value xi of X do 
			Q(xi)<--Enumerate-All(bn.Vars, e(xi))
				where e(xi) is e exteneded with X=xi
		return Normalize(Q)
	
	Function Enumerate-All(vars,e) returns a real number
		if Empty(vars) then return 1.0
		Y <--First(vars)
		if Y has value y in e
			then return P(y|parents(Y)) * Enumerate-All(Rest(vars),e)
			else return summing-y P(y|parents(Y))* Enumertate-All(Rest(vars),e, y)
				where ey is e extended with Y=y
			
	
	*/
	
	//the same as enumerate ask but accords with the name in Inferencer.java
	public bn.base.Distribution query(RandomVariable X, Assignment e, BayesianNetwork bn) {
		bn.base.Distribution Q=new bn.base.Distribution(X);
		for(bn.core.Value xi: X.getDomain()) {
			e.put(X, xi);
			Q.set(xi, EnumerateAll(bn.getVariablesSortedTopologically(), e, bn));
			
		}
		Q.normalize();
		return Q;
	}
	
	
	public double EnumerateAll(List<RandomVariable> vars, Assignment e, BayesianNetwork bn) {
		if(vars.isEmpty()) {
			return 1.0;
		}
		
		RandomVariable Y=vars.get(0);
		if(e.containsKey(Y)) {
			return bn.getProbability(Y, e)*EnumerateAll(vars.subList(1, vars.size()), e, bn);
		}else {
			double sum=0.0;
			for(bn.core.Value v: Y.getDomain()) {
				Assignment newE=e.copy();
				newE.put(Y, v);
				sum+=bn.getProbability(Y, newE)*EnumerateAll(vars.subList(1, vars.size()), newE, bn);
			}
			
			return sum;
		}
	}



}
