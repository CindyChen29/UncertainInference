package bn.inference;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import bn.core.Assignment;
import bn.base.BayesianNetwork;
import bn.base.Distribution;
import bn.base.StringValue;
import bn.core.RandomVariable;

public class RejectionSampling {
	public Random random = new Random();
	/*
	 * function Rejection-Sapling(X,e,bn,N) returns an estiamte of P(X|e)
	 * 	inputs: X, the query
	 * 			e, observed values for variables
	 * 			bn, a Bayesian network
	 * 			N, the total number of samples to be generated
	 * 
	 * local variables: N, a vector of counts for each value of X, initially zero
	 * 
	 * for j=1 to N do 
	 * x <- Prior-Sample(bn)
	 * if x is consistent with e then 
	 * 		N[x]<-N[x]+1 where x is the value of X in x
	 * return Normalize(N)
	 */

//	//rejection sampling (main method)

	
	public bn.base.Distribution rejectionSampling(RandomVariable X, Assignment e, BayesianNetwork bn, int N){
		bn.base.Distribution Q=new Distribution(X);
		
		for(int j=0;j<N;j++) {
			Assignment sample=priorSample(bn);
			if(isConsistent(sample, e)) {
				if(!Q.containsKey(sample.get(X))) {
					Q.put(sample.get(X), 1.0);
				}else {
					Q.put(sample.get(X), Q.get(sample.get(X))+1.0);
				}
			}
		}
		
		Q.normalize();
		return Q;
	}
	
	
	public boolean isConsistent(Assignment a, Assignment e) {
		for(RandomVariable xi: e.variableSet()) {
			if(!a.get(xi).equals(e.get(xi))) {
				return false;
			}
		}
		return true;
	}
	
	//we need to generate the sampling 
	public void randomSampling(RandomVariable X, Assignment assignment, BayesianNetwork bn) {
		Double[] intervalArray=new Double[X.getDomain().size()];
		Map<bn.core.Value, Double[]> valueMap=new HashMap<bn.core.Value, Double[]>();
		double sum=0.0;
		for(bn.core.Value v: X.getDomain()) {
			intervalArray=new Double[X.getDomain().size()];
			assignment.put(X, v);
			for(int i=0; i<intervalArray.length;i++) {
				intervalArray[i]=sum;
				if(i!=intervalArray.length-1)
					sum+=bn.getProbability(X, assignment);
			}
			valueMap.put(v, intervalArray);
			
		}
		
		double p=random.nextDouble();
		for(bn.core.Value v: valueMap.keySet()) {
			for(int i=0;i<intervalArray.length-1;i++) {
				
				//see which interval the sampling is in
				if(p>=valueMap.get(v)[i]&&p<=valueMap.get(v)[i+1])
					assignment.put(X, v);
			}
		}
		
	}
	

//	function PRIOR-SAMPLE(bn) returns an event sampled from the prior specified by bn
//	inputs: bn, a Bayesian network specifying joint distribution P(X1, . . . , Xn)
//	x←an event with n elements
//	foreach variable Xi in X1, . . . , Xn do
//	x[i]←a random sample from P(Xi | parents(Xi))
//	return x
	public Assignment priorSample(BayesianNetwork bn) {
		
		Assignment assignment=new bn.base.Assignment();
		List<RandomVariable> list= bn.getVariablesSortedTopologically();
		for(RandomVariable xi: list) {
			randomSampling(xi,assignment,bn);
		}
		return assignment;
	}




}
